package com.kutsyk.backup.ftp;

/**
 * Created by KutsykV on 09.06.2015.
 */
public class FTPException extends Exception {
    public FTPException(String message) {
        super(message);
    }
}
